/* Hameed Sahib
018594925
CECS 275  Project 1
2/27/20
In this project we were tasked with creating a card memory games where the user has 4 files to choose from, and must match 8 pairs of cards in order to win the game.
*/

#include <iostream>
#include <stdio.h>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

// Checks if userinput is a valid integer in the given range.
int getIntRange(int low, int high) {
	int input = 0;
	bool valid = false;
	while(!valid) {
		if(cin >> input) {
			if(input >= low && input <= high) {
				valid = true;
			} else {
				cout<< "Invalid Input. Try again: ";
			}
		} else {
			cin.clear();
			string invalid;
			cin >> invalid;
			cout<< "Invalid Input. Try again: ";
		}
	}
	return input;
}


/* gets a valid yes/no answer from the user and returns true if yes, false if no */
bool getYesNo( ) {
	string input;
	bool valid = false;
	while(!valid) {
		cin >> input;
		if(input == "yes" || input == "Yes" || input == "YES" || input == "Y" || input == "y") {
			return true;
		} else if(input == "no" || input == "No" || input == "NO" || input == "N" || input == "n") {
			return false;
		} else {
			cout<< "Invalid Input. Try again: ";
		}
	}
	return false;
}

//@param string cards[4][4] is the array of cards
//This function takes in the array of cards and randomly takes
// two cards and swaps their values. This is repeated 100 times.

void shuffle(string cards[4][4])
{
  srand(time(NULL));
  for(int i =0; i < 100; i++)
  {
    int randomNum1 = rand() % 16 + 1;
    int randomNum2 = rand() % 16 + 1;
    int row1 = (randomNum1 - 1) / 4;
    int col1 = (randomNum1 - 1) % 4;
    int row2 = (randomNum2 - 1) / 4;
    int col2 = (randomNum2 - 1) % 4;
    string temp;
    temp = cards[row1][col1];
    cards[row1][col1] = cards[row2][col2];
    cards[row2][col2] = temp;
  }
}

//@ return input: is the card choice the user makes. 
/*This function is responsible for taking the users input of what
card the user wants to check if it matches. */

int getChoice()
{
  int input = 0;
  input = getIntRange(1,16);

  return input;
  
}

/*@param cbool cardFaceUp[4][4] is the boolean array which keeps track of which card is face up or face down. */
/* This function is resposnsible for flipping a card face up if it
is face down and face down if the card is face up. */

void flipChoice(bool cardFaceUp[4][4], int card)
{
  int row1 = 0;
  int column1 = 0;

  /* We use this calculation to find the corresponding value in the array. */
  row1 = (card - 1) / 4;
  column1 = (card - 1) % 4;

  if (cardFaceUp[row1][column1] == true)
  {
    cardFaceUp[row1][column1] = false;
  }
  else
  {
    cardFaceUp[row1][column1] = true;
  }
 
}
//@param string cards[4][4]: is the array of cards
//@param option1: is the first card the user picked
//@param option2: is the second card the user picked.
//@return true: return true if two cards are a match.
//@return false: returns false if the two cards are not a match.

/*  This function is responsible for taking in both the cards the user picked, and determining if they are a match or not. If they are not a match it will return false. If they are a match it will return true. */

int isMatch(string cards[4][4], int option1, int option2) 
{
  int row1 = 0;
  int column1 = 0;

  row1 = (option1 - 1) / 4;
  column1 = (option1 - 1) % 4;


  int row2 = 0;
  int column2 = 0;


  row2 = (option2- 1) / 4;
  column2 = (option2 - 1) % 4;

  /* Comparing both the values in the array to see if they are equal or not. */

  if(cards[row1][column1] == cards[row2][column2])
  {
    return true;
  }
  else
  {
    return false;
  }
}

//@return true: returns true if the card is already face up.
//@return false: returns false if the cards is not face up.
//@param bool cardFaceUp: is the boolean array of the cards.
//@param card: Is the card that the user has picked.
/* This function is responsible for taking in the boolean array and the card that the user has picked, and then determines if that particular card is already face up or not. Returns true if it is. Returns false if it isn't. */

int checkFlipped(bool cardFaceUp[4][4], int card) 
{
  int row1 = 0;
  int column1 = 0;


  row1 = (card - 1) / 4;
  column1 = (card - 1) % 4;

  if(cardFaceUp[row1][column1] == true )
  {
    return true;
  }
  else
  {
    return false;
  }
}

//@return userinput: Is the file the user wants passed in
/* This function is responsible for displaying the options is a menu format to the user, and then returns it to the readFile function. */

int getFileChoice()
{
  cout << "Memory Game" << endl;
  cout << "           " << endl;
  cout << "1. Letters" << endl;
  cout << "2. Numbers" << endl;
  cout << "3. Animals" << endl;
  cout << "4. Objects" << endl;
  
  cout << "          " << endl;

  cout << "Enter choice: ";


  int userinput = 0;
  userinput = getIntRange(1,4);

  return userinput;

}

//@param cards[4][4]: is the array of created cards.
/* This function is responsible for taking in the users file selection choice and then reading in the file's contents into the array of created cards. */

void readFile(string cards[4][4])
{
  int userinput = 0;
  userinput = getFileChoice();
  fstream file;
  string input;
  
  string arr[8];

  if (userinput == 1)
  {

    file.open("letters.txt", ios::in);

  }

  if (userinput == 2)
  {

    file.open("numbers.txt", ios::in);

  }

  if (userinput == 3)
  {

    file.open("animals.txt", ios::in);
    
  }

  if (userinput == 4)
  {

    file.open("objects.txt", ios::in);

  }

  if (file)
  {
    int i =0;
    while(getline(file,input))
    {
       arr[i] = input;
        i++;
      }
      file.close();
    }
    else
    {
      cout << "Could Not Open File." << endl;
    }

/* Passes in the array of value into the 2D array of cards */

/*
  cards[0][0] = arr[0];
  cards[0][1] = arr[1];
  cards[0][2] = arr[2];
  cards[0][3] = arr[3];
  cards[1][0] = arr[4];
  cards[1][1] = arr[5];
  cards[1][2] = arr[6];
  cards[1][3] = arr[7];
  cards[2][0] = arr[0];
  cards[2][1] = arr[1];
  cards[2][2] = arr[2];
  cards[2][3] = arr[3];
  cards[3][0] = arr[4];
  cards[3][1] = arr[5];
  cards[3][2] = arr[6];
  cards[3][3] = arr[7]; */
  int f =0;
  int count = 0;
  for(int i =0; i<4; i++)
  {
    for(int j =0; j<4; j++)
    {
      if(count == 0)
      {
        cards[i][j] = arr[f];
        count= count +1 ;
      } 
      else
      {
        cards[i][j] = arr[f];
        f++;
        count = 0;
      }
    }
  }

}

//@param cards[4][4]: Is the array of created cards
//@param cardFaceUp[4][4]: Is the boolen array of card face.

/* This function is responsible for physically creating the cards that are displayed into the console. It takes into account the spacing in order to fit the various strings in the differnt files, within the cards. */

void displayBoard(string cards[4][4], bool cardFaceUp[4][4]) 
{

  for (int i = 0; i < 4; i++)
  {
    cout << "+---------+   +---------+   +---------+   +---------+";
    cout << "\r\n";
    cout << "|         |   |         |   |         |   |         |";
    cout << "\r\n";

    for (int j = 0; j < 4; j++)
    {
      string displayStr;
      if (cardFaceUp[i][j] == true)
      {
        displayStr = cards[i][j];
      }
      else
      {
        char intStr[4];
        sprintf(intStr, "%d", i * 4 + j + 1);
        displayStr = string(intStr);
      }

      cout << "|";
      int numBlanks = (9 - displayStr.length())/2;
      for (int k = 0; k < numBlanks; k++)
      {
        cout <<" ";
      }
      cout << displayStr;
      numBlanks = 8 - numBlanks - displayStr.length() + 1;
      for (int k = 0; k < numBlanks; k++)
      {
        cout <<" ";
      }
       cout << "|   ";
      }

      cout << "\r\n";
      cout << "|         |   |         |   |         |   |         |";
      cout << "\r\n";
      cout << "+---------+   +---------+   +---------+   +---------+";
      cout << "\r\n";
  }
}

int main()
{
  /* Creating our array of cards and our boolena array which will
  keep track of the what side the card is facing. */

  string cards[4][4];
  bool cardFaceUp[4][4];
  

  // Intially setting them to false, which is face down.

  for (int i = 0; i < 4; i++)
  {
    for (int j = 0; j < 4; j++)
      {
        cardFaceUp[i][j] = false;
      }
  }
  readFile(cards);
  shuffle(cards);
  displayBoard(cards, cardFaceUp);

  int matchcount = 0;

  /* While loop will keep the user in the game until they finish it by matching all 8 pairs of the cards. */

  while(true)
  { 
      int option1 = 0;
      cout << "Enter first card: ";
      option1 = getChoice();

      while (checkFlipped(cardFaceUp, option1) == true)
      {
        cout << "Card already picked/matched" << endl;
        cout << "Pick a different card: ";
        option1 = getChoice();
      }

      flipChoice(cardFaceUp, option1);
      displayBoard(cards, cardFaceUp);


      cout << "Enter second card: ";
      int option2 = 0;
      option2 = getChoice();
    
      while (checkFlipped(cardFaceUp, option2) == true)
      {
        cout << "Card already picked/matched" << endl;
        cout<< "Pick a different card: ";
        option2 = getChoice();
      }
      
      flipChoice(cardFaceUp, option2);
      displayBoard(cards, cardFaceUp);

      bool check = isMatch(cards, option1, option2);

      if(check == true)
      {
        cout <<"              " << endl;
        cout << "Match Found!" << endl;
        matchcount ++;
        cout <<"              " << endl;
        
      }

      if(check == false)
      {
        cout <<"              " << endl;
        cout <<" Match Not Found." << endl; 
        flipChoice(cardFaceUp, option1);
        flipChoice(cardFaceUp, option2);
        cout << "           " << endl;
      }

      displayBoard(cards, cardFaceUp);


      if (matchcount == 8)
      {
        cout << "                                 " << endl;
        cout << "Memory game complete: All cards were matched!" << endl;
        cout << "Would you like to play again? Yes/No:  ";

        bool userinput;
        userinput = getYesNo();

        if(userinput == true)
        {
          for (int i = 0; i < 4; i++)
          {
            for (int j = 0; j < 4; j++)
            {
              cardFaceUp[i][j] = false;
            }
          }

          matchcount = 0;
          readFile(cards);
          shuffle(cards);
          displayBoard(cards, cardFaceUp);
          continue;
        }

        if(userinput == false)
        {
          cout <<"              " << endl;
          cout <<"Thanks for playing!" << endl;
          break;
        }
      }

  }
}


